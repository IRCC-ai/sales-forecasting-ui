
export default function Login() {
  return (
    <div style={{ padding: 20 }}>
      <h2>Login</h2>
      <form>
        <input type="email" placeholder="Email" defaultValue="demo@example.com" /><br />
        <input type="password" placeholder="Password" defaultValue="password123" /><br />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
