# Sales Forecasting UI

Full-stack sales forecasting app with dummy login, role-based views, GPT summaries, and quota tracking.